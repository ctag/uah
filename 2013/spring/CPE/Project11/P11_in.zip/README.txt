the files P11_in1.txt to P11_in4.txt can be used when running
your program normally - enter in these files as the name
of the input file and then proceed to make selections for
shots interactively.

The input files in1.txt to in4.txt are for redirected input.
These files containg the name of the input file and then any 
shot selections that are made.  to run your program with these
files, you perform the following(shown for running with input
file in1.txt):
g++ Project_11.cpp -o Project_11
./Project_11 < in1.txt

The program should successfully complete for this input file.
If it does not successfully complete, then there is a processing
problem with your program. You can run this with the sample solution
by typing the following at a terminal prompt:
/home/work/cpe112/Executables/Project_11/Project_11_solution < in1.txt


